package com.days.Java17API;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Java17ApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
