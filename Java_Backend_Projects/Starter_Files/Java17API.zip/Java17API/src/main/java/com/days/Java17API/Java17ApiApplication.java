package com.days.Java17API;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Java17ApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Java17ApiApplication.class, args);
	}

}
