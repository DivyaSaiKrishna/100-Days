package com.Days.Java8API;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Java8ApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
