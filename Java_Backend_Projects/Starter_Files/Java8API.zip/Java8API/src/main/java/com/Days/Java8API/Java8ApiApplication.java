package com.Days.Java8API;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Java8ApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Java8ApiApplication.class, args);
	}

}
