package com.dsk.khatting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KhattingApplication {

	public static void main(String[] args) {
		SpringApplication.run(KhattingApplication.class, args);
	}

}
