package com.dsk.khatting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KhattingApplicationTests {

	@Test
	void contextLoads() {
	}

}
